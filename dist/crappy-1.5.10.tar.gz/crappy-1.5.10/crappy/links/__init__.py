# coding: utf-8

from .link import Link, link
