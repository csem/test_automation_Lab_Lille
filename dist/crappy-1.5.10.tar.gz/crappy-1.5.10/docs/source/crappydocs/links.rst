=====
Links
=====

Link
----
.. automodule:: crappy.links.link
   :members:
