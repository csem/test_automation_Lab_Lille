=========
Actuators
=========

Actuator
--------
.. automodule:: crappy.actuator.actuator
   :members:

Biaxe
-----
.. automodule:: crappy.actuator.biaxe
   :members:

Biotens
-------
.. automodule:: crappy.actuator.biotens
   :members:

CM Drive
--------
.. automodule:: crappy.actuator.cmDrive
   :members:

Fakemotor
---------
.. automodule:: crappy.actuator.fakemotor
   :members:

Motorkit pump
-------------
.. automodule:: crappy.actuator.motorkit_pump
   :members:

Oriental
--------
.. automodule:: crappy.actuator.oriental
   :members:

Pololu Tic
----------
.. automodule:: crappy.actuator.pololu_tic
   :members:

Servostar
---------
.. automodule:: crappy.actuator.servostar
   :members:

TRA6PPD
-------

.. automodule:: crappy.actuator.tra6ppd
   :members:
