===================
License information
===================

See the file `LICENSE.txt
<https://github.com/LaboratoireMecaniqueLille/crappy/blob/master/LICENSE>`_ for
information on the history of this software, terms & conditions for usage, and a
DISCLAIMER OF ALL WARRANTIES.
