===========
Bug reports
===========

Please report bugs on the `dedicated GitHub page
<https://github.com/LaboratoireMecaniqueLille/crappy/issues>`_ of the project.
