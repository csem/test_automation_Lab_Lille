======
Crappy
======

This package aims to provide easy-to-use and open-source tools for command and
acquisition on complex experimental setups.

.. toctree::
  :maxdepth: 2

  whatiscrappy
  installation
  tutorials
  embedded
  features
  blocklist
  documentation
  developers
  citing
  bugs
  license
