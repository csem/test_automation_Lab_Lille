=====
Block
=====

.. automodule:: crappy.blocks.block
   :members:
