=========
Modifiers
=========

Modifier
--------
.. automodule:: crappy.modifier.modifier
   :members:

Demux
-----
.. automodule:: crappy.modifier.demux
   :members:

Differentiate
-------------
.. automodule:: crappy.modifier.differentiate
   :members:

Integrate
---------
.. automodule:: crappy.modifier.integrate
   :members:

Mean
----
.. automodule:: crappy.modifier.mean
   :members:

Median
------
.. automodule:: crappy.modifier.median
   :members:

Moving average
--------------
.. automodule:: crappy.modifier.moving_avg
   :members:

Moving med
----------
.. automodule:: crappy.modifier.moving_med
   :members:

Offset
------
.. automodule:: crappy.modifier.offset
   :members:


Trig on change
--------------
.. automodule:: crappy.modifier.trig_on_change
   :members:

Trig on value
-------------
.. automodule:: crappy.modifier.trig_on_value
   :members:
